package com.company.models;

public enum ExpenseType {
    EQUAL,
    EXACT
}
